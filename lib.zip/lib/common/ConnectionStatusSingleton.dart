import 'dart:io'; //InternetAddress utility
import 'dart:async';

import 'package:connectivity_plus/connectivity_plus.dart'; //For StreamController/Stream


class ConnectionStatusSingleton {
  ConnectionStatusSingleton._();

  static final _instance = ConnectionStatusSingleton._();
  static ConnectionStatusSingleton get instance => _instance;
  final _connectivity = Connectivity();
  final _controller = StreamController.broadcast();
  Stream get myStream => _controller.stream;

  void initialise() async {
    ConnectivityResult result = await _connectivity.checkConnectivity();
    _checkStatus(result);
    _connectivity.onConnectivityChanged.listen((result) {
      _checkStatus(result);
    });
  }

  void _checkStatus(ConnectivityResult result) async {
    bool isOnline = false;
    try {
      final result = await InternetAddress.lookup('https://www.google.com/');
      isOnline = result.isNotEmpty && result[0].rawAddress.isNotEmpty;
    } on SocketException catch (_) {
      isOnline = false;
    }
    _controller.sink.add({result: isOnline});
  }

  void disposeStream() => _controller.close();
}