
//const BASE_URL = "http://52.55.57.181/disaster_reconstruction/index.php/api/";
const BASE_URL = "http://application.dra.gov.bs/api/";